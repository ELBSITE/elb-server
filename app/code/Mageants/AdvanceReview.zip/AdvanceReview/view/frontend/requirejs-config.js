var config = {
map: {
    '*': {
        jquerymodal: 'Mageants_AdvanceReview/js/jquery.modal.min',
    }
}
};