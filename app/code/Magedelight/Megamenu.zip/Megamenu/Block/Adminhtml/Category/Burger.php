<?php
namespace Magedelight\Megamenu\Block\Adminhtml\Category;

class Burger extends \Magento\Backend\Block\Template
{
    protected $_template = 'custom.phtml';
}
